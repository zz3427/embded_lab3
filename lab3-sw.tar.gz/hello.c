/*
 * Userspace program that communicates with the vga_ball device driver
 * through ioctls
 *
 * Stephen A. Edwards
 * Columbia University
 */

#include <stdio.h>
#include "vga_ball.h"
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

int vga_ball_fd;

/* Read and print the coord */
void print_coords(void) {
  vga_ball_arg_t vla;

  if (ioctl(vga_ball_fd, VGA_BALL_READ_COORD, &vla)) {
      perror("ioctl(VGA_BALL_READ_COORD) failed");
      return;
  }
  printf("x=%u y=%u\n", vla.x, vla.y);
}

/* Set the coord */
void set_coords(unsigned char x, unsigned char y)
{
  vga_ball_arg_t vla;
  vla.x = x;
  vla.y = y;

  if (ioctl(vga_ball_fd, VGA_BALL_WRITE_COORD, &vla)) {
      perror("ioctl(VGA_BALL_SET_COORD) failed");
      return;
  }
}

int main()
{

  static const char filename[] = "/dev/vga_ball";
  int x = 100;
  int y = 100;
  int dx = 2;
  int dy = 2;

  printf("VGA ball userspace progrm started\n");

  if ((vga_ball_fd = open(filename, O_RDWR)) == -1) {
      fprintf(stderr, "could not open %s\n", filename);
      return -1;
  }

  print_coords();

  while (1) {
      set_coords((unsigned char)x, (unsigned char)y);
      usleep(30000);

      x += dx;
      y += dy;

      if (x <= 10 || x >= 245)
          dx = -dx;

      if (y <= 10 || y >= 235)
          dy = -dy
  }

  close(vga_ball_fd);
  return 0;
}
