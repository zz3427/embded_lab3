#ifndef _VGA_BALL_H
#define _VGA_BALL_H

#include <linux/ioctl.h>

typedef struct {
  unsigned char x;
  unsigned char y;
} vga_ball_arg_t;



#define VGA_BALL_MAGIC 'q'

/* ioctls and their arguments */
#define VGA_BALL_WRITE_COORD _IOW(VGA_BALL_MAGIC, 1, vga_ball_arg_t)
#define VGA_BALL_READ_COORD  _IOR(VGA_BALL_MAGIC, 2, vga_ball_arg_t)

#endif
